/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Rectangle.h
 * Author: dai
 *
 * Created on 26. November 2019, 10:24
 */

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "IShape.h"

class Rectangle : public IShape {
public: 
    Rectangle();
    Rectangle(int, int);
    ~Rectangle();
    float getArea();  // Interface Methode von IShape
private:
   int hoehe;
   int breite;
};


#endif /* RECTANGLE_H */

