/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Circle.h
 * Author: dai
 *
 * Created on 26. November 2019, 10:36
 */

#ifndef CIRCLE_H
#define CIRCLE_H

#include "IShape.h"

class Circle : public IShape {
public:
    Circle();
    Circle(double);
    virtual ~Circle();
    float getArea();  // Interface Methode von IShape

private:
    double radius;
};

#endif /* CIRCLE_H */

