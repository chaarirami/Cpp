/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: dai
 *
 * Created on 8. Oktober 2019, 11:10
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;


// #include "IShape.h"
#include "Circle.h"
#include "Rectangle.h"

int main() {
   IShape *ptr = NULL;
   Rectangle rec(2,3);
   cout << "Retangle class: " << rec.getArea() << endl;
 
   ptr = &rec;
   cout << "Rectangle interface: " << ptr->getArea() << endl;
    
   Circle cir(2.3);
   ptr = &cir;
   cout << "Circle interface: " << ptr->getArea() << endl;
   
   return 0;
}






