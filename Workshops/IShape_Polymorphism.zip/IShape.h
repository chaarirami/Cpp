/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   IShape.h
 * Author: dai
 *
 * Created on 26. November 2019, 10:15
 */

#ifndef ISHAPE_H
#define ISHAPE_H

class IShape{
public:
    virtual ~IShape() {};
    virtual float getArea() = 0;   // Pure Virtual Methode
};

#endif /* ISHAPE_H */

